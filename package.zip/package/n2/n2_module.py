def func3(param1: str, param2: dict):
    return param1, param2


async def cofunc3():
    return "ok"


class Class3:
    def __init__(self) -> None:
        pass

    def method3(self):
        return "classic response"
