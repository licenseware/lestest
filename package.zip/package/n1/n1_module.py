def func2(param1: str, param2: dict):
    return param1, param2


async def cofunc2():
    return "ok"


class Class2:
    def __init__(self) -> None:
        pass

    def method2(self):
        return "classic response"
